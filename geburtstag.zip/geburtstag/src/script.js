function openCard() {
  document.querySelector(".card").classList.add("open");
}

function closeCard() {
  document.querySelector(".card").classList.remove("open");
}
